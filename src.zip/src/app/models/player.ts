export interface player{
    id:Number,
    firstName:string,
    lastName:string,
    age:number,
    gender:string,
    categoryId:string,
}
